<template>
    <div
      class="limit-box"
      @mousemove="handleMouseMove"
      @mouseleave="handleMouseLeave"
    >
      <!-- 显示鼠标在限定框内的坐标 -->
      <p>X: {{ mouseX }}</p>
      <p>Y: {{ mouseY }}</p>
    </div>
  </template>
  
  <script>
  import { ref } from 'vue';
  
  export default {
    name: 'MouseTracker',
    setup() {
      const mouseX = ref(0); // 初始化鼠标 X 坐标为 0
      const mouseY = ref(0); // 初始化鼠标 Y 坐标为 0
  
      // 定义鼠标移动事件的处理函数
      const handleMouseMove = (event) => {
        const limitBox = event.currentTarget; // 获取限定框元素
        const rect = limitBox.getBoundingClientRect(); // 获取限定框的位置信息
  
        // 计算鼠标在限定框内的相对坐标
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
  
        // 限制鼠标坐标范围
        // 例如，只允许在限定框的左上角 200px x 100px 区域内显示坐标
        const max_X = 200; // X 坐标的最大值
        const max_Y = 100; // Y 坐标的最大值
  
        if (x >= 0 && x <= max_X && y >= 0 && y <= max_Y) {
          mouseX.value = x;
          mouseY.value = y;
        } else {
          // 如果鼠标超出指定范围，坐标重置为 0
          mouseX.value = 0;
          mouseY.value = 0;
        }
      };
  
      // 鼠标离开限定框时重置坐标
      const handleMouseLeave = () => {
        mouseX.value = 0;
        mouseY.value = 0;
      };
  
      return {
        mouseX,
        mouseY,
        handleMouseMove,
        handleMouseLeave
      };
    }
  };
  </script>
  
  <style scoped>
  .limit-box {
    width: 200px; /* 修改限定框的宽度 */
    height: 100px; /* 修改限定框的高度 */
    border: 2px solid #007bff; /* 限定框边框样式 */
    margin: 20px auto; /* 水平居中，可以通过修改 margin 来调整位置 */
    position: relative; /* 确保相对定位 */
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #f8f9fa; /* 背景颜色 */
  }
  </style>