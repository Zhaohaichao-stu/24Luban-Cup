<template>
  <div id="app">
    <div class="container">
      <h1>限定框内鼠标指针位置</h1>
      <MouseTracker />
    </div>
  </div>
</template>

<script>
import MouseTracker from './components/MouseTracker.vue';

export default {
  name: 'App',
  components: {
    MouseTracker
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.container {
  text-align: center;
  margin-top: 50px;
}
</style>