<template>
  <div class="container">
    <h1>鼠标指针位置</h1>
    <!-- 动态绑定鼠标 X 和 Y 坐标 -->
    <p>X: {{ mouseX }}</p>
    <p>Y: {{ mouseY }}</p>
  </div>
</template>

<script>
import { ref, onMounted, onUnmounted } from 'vue';

export default {
  name: 'App',
  setup() {
    const mouseX = ref(0); // 初始化鼠标 X 坐标为 0
    const mouseY = ref(0); // 初始化鼠标 Y 坐标为 0

    // 定义鼠标移动事件的处理函数
    const handleMouseMove = (event) => {
      // 更新鼠标位置
      mouseX.value = event.clientX; // 获取鼠标相对于视口的 X 坐标
      mouseY.value = event.clientY; // 获取鼠标相对于视口的 Y 坐标
    };

    // 在组件挂载时添加鼠标移动事件监听器
    onMounted(() => {
      window.addEventListener('mousemove', handleMouseMove);
    });

    // 在组件卸载时移除鼠标移动事件监听器，避免内存泄漏
    onUnmounted(() => {
      window.removeEventListener('mousemove', handleMouseMove);
    });

    return {
      mouseX,
      mouseY
    };
  }
};
</script>

<style scoped>
.container {
  text-align: center; 
  margin-top: 50px; 
}
</style>